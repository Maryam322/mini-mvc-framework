from ..models.exceptions import ValidationError
import re
class Validator:
    def validate(self, value):
        raise NotImplementedError
class RequiredValidators:
    def  call(self,value):
        pass
class LengthValidator(Validator):
    def __init__(self, min_len=0, max_len=None):
        self.min_len = min_len
        self.max_len = max_len

    def validate(self, value):
        if not value:
            return True # Let required field handle empty
        if len(value) < self.min_len:
            raise ValidationError(f"Length less than {self.min_len}")
        if self.max_len and len(value) > self.max_len:
            raise ValidationError(f"Length greater than {self.max_len}")

