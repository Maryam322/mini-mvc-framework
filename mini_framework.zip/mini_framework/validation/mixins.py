from ..models.exceptions import ValidationError

class ValidationMixin:
    def validate_field(self, validator, value):
        try:
            validator.validate(value)
            return True, None
        except ValidationError as e:
            return False, str(e)

                
                