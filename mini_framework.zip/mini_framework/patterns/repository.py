class Repository:
    def __init__(self, model_class):
        self.model_class = model_class

    def get_all(self):
        return self.model_class.all()

    def get_by_id(self, id):
        return self.model_class.get(id)

    def create(self, **kwargs):
        # Wraps model creation
        instance = self.model_class(**kwargs)
        instance.save()
        return instance