class ModelFactory:
    @staticmethod
    def create_instance(model_class, **kwargs):
        """
        Factory method to create model instances.
        Can be extended to support complex creation logic.
        """
        return model_class(**kwargs)