import json
class Request:
    def __init__(self,path,method,body=None):
        self.path = path
        self.method = method
        self.body = body
        self.params = {}
    def validates(self,required_field):
        missing=[]
        for field in required_field:
            if field not in self.body:
                missing.append(field)
        if missing:
            raise ValueError(f"Missing fields: {', '.join(missing)}")
        
        def json(self):
            """Parses JSON body if available."""
        if not self.body:
            return {}
        try:
            return json.loads(self.body)
        except json.JSONDecodeError:
            return {}

    def get_header(self, key):
        return self.headers.get(key)
