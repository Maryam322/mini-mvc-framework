class Response:
    def __init__(self,data,status=200):
        self.data = data
        self.status = status
    @classmethod
    def json(cls, data, status=200):    
        return cls(data=data, status=status)
    @classmethod
    def error(cls,message,status=400):
        return cls({"error": message}, status)
    
    @classmethod
    def not_found(cls, message="Not Found"):
        return cls.json({"error": message}, status=404)

    @classmethod
    def bad_request(cls, message="Bad Request"):
        return cls.json({"error": message}, status=400)

    @classmethod
    def created(cls, data):
        return cls.json(data, status=201)
