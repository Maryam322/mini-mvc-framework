from core.response import Response

class Router:
    def __init__(self):
        self.routes = {}

    def add_route(self, path, method, handler):
        key = (path.rstrip('/'), method.upper())
        self.routes[key] = handler

    def resolve(self, request):
        req_method = request.method.upper()
        req_path = request.path.rstrip('/')
        req_parts = req_path.strip('/').split('/') if req_path.strip('/') else []

        for (route_path, route_method), handler in self.routes.items():
            if route_method != req_method:
                continue

            route_parts = route_path.strip('/').split('/') if route_path.strip('/') else []
            if len(route_parts) != len(req_parts):
                continue

            params = {}
            matched = True
            for r_part, p_part in zip(route_parts, req_parts):
                if r_part.startswith('<') and r_part.endswith('>'):
                    params[r_part[1:-1]] = p_part
                elif r_part != p_part:
                    matched = False
                    break

            if matched:
                request.params = params
                return handler(request)

        return Response.error("Route not found", 404)