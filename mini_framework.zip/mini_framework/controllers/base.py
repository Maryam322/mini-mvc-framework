from ..core.response import Response

class Controller:
    def __init__(self, request):
        self.request = request

    def json_response(self, data, status=200):
        return Response.json(data, status)
        
    def error_response(self, message, status=400):
        return Response.json({"error": message}, status)
        