from flask import Response 
from controllers.base import BaseController

from core.response import Response


class  ModelController(BaseController):
    model=None 
    def get(self, id=None):
        if id:
            obj = self.model.filter(id=id)
            if obj:
                obj=self.model.get(id=id)
                return Response.json(obj.to_dict())
            return Response.json([o.to_dict() for o in self.model.all()]
            )

    def post(self, data):
        obj=self.model.create(**self.body.data) 
        return Response.json(obj.to_dict(), status=201)
    def put(self, id):
            obj = self.model.get(id=id)
            obj.update(**self.request.body)
            return Response.json(obj.to_dict())

    def delete(self, id):
        self.model.delete(id)
        return Response.json({"message": "deleted"})
   
            