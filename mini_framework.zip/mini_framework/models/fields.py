from datetime import datetime
from .exceptions import ValidationError 
class Field:
    def __init__(self,required=False,default=None):
        self.required = required
        self.default = default
class Charfield(Field):
    def __init__(self, max_length=255, **kwargs):
        super().__init__(**kwargs)
        self.max_length = max_length
class IntegerField(Field):
    pass
class DateTimeField(Field):
    def __init__(self,auto_now=False, **kwargs):
        super().__init__(**kwargs)
        self.auto_now = auto_now