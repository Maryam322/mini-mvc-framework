from datetime import datetime
from .fields import Fields, DateTimefield
from .exceptions import ValidationError
class ModelMeta(type):
    """"Metaclass for models to handle metadata and field collection."""
    def __new__(cls, name, bases, attrs):
        fields={}
        for key, value in attrs.items():
            if isinstance(value, Fields):
                fields[key] = value
            attrs["_fields"] = fields
        attrs["_storage"] = []  # in-memory storage
        return super().__new__(cls, name, bases, attrs)
class Model(metaclass=ModelMeta):
    """Base model class """
    def __init__(self, **kwargs):
        for field_name, field in self._fields.items():
           if field.required and field_name not in kwargs:
               raise ValidationError(f"Field '{field_name}' is required.")
           value=kwargs.get(field_name, None)
        if isinstance(field, DateTimefield) and value is None:
               value = datetime.now()   
        setattr(self, field_name, value)
    def save(self):
        self.__class__._storage.append(self)
    @classmethod
    def get_all(cls):
        return cls._storage
    @classmethod
    def filter(cls, **kwargs):
        results = []
        for instance in cls._storage:
            match = all(getattr(instance, k) == v for k, v in kwargs.items())
            if match:
                results.append(instance)
        return results
    def __repr__(self):
        field_values = ', '.join(f"{field}={getattr(self, field)!r}" for field in self._fields)
        return f"<{self.__class__.__name__}({field_values})>"