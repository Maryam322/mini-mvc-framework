class ValidationError(Exception):
    """Raise when data validation fails."""
    pass 

class ObjectDoesNotExist(Exception):
    pass