# models/__init__.py
from .base import Model
from .fields import CharField, IntegerField, DateTimeField

# Blog Models
class User(Model):
    name = CharField(max_length=100, required=True)
    email = CharField(max_length=200, required=True)
    created_at = DateTimeField(auto_now=True)

class Post(Model):
    title = CharField(max_length=200, required=True)
    content = CharField(max_length=5000)
    author_id = IntegerField(required=True)
    created_at = DateTimeField(auto_now=True)

class Comment(Model):
    post_id = IntegerField(required=True)
    content = CharField(max_length=500, required=True)
    author_id = IntegerField(required=True)
    created_at = DateTimeField(auto_now=True)
